# Madhav — landing, login + post selection, public portal, citizen hub, grievance hub, assistant UI

Branch: `madhav` (do not merge into `atulit`).

Frontend only (`apps/portal`). No change to `apps/api`, `packages/db`, `packages/shared` or `package.json`.

## Copy into the repo

Copy `apps/` from this folder over the repo root. Paths match the repo exactly.

## Created
- `apps/portal/lib/roles.ts`: role labels, plus the post → home route map. Unknown roles fall back to `/session`; add more dashboards here.
- `apps/portal/lib/public-api.ts`: client for `/api/v1/public/*`. Sends no cookies, so a citizen sees only what the public_* views return (G22, G13).
- `apps/portal/lib/public-links.ts`: WS3 token page paths and SMS-link → token parsing.
- `apps/portal/lib/i18n/public.ts`: en/hi/mr strings. The hi/mr strings are `needs_native_review`.
- `apps/portal/components/post-switcher.tsx`
- `apps/portal/components/public/village-picker.tsx`
- `apps/portal/components/public/token-link-form.tsx`
- `apps/portal/app/(public)/portal/layout.tsx` and `portal-shell.tsx`: public layout, language switcher, provenance/asOf footer.
- `apps/portal/app/(public)/portal/page.tsx`, `search/`, `notices/`, `objection/`, `my-land/`, `grievance/`
- `apps/portal/app/assistant/page.tsx`

## Modified (see `modified-files.diff`)
- `app/page.tsx`: landing page.
- `app/layout.tsx`: two nav links only (Assistant, Public portal).
- `app/login/page.tsx` and `login-form.tsx`: post selection after sign-in, role-based redirect, demo quick-fill in demo mode only.
- `app/session/page.tsx`: uses the shared `PostSwitcher`, adds "Open my dashboard" and "View the public portal". This page was WS1's; the change is small and easy to revert if Chaitanya prefers.

## Please verify with repo access
1. **WS3 paths.** The passbook and acknowledgement pages are assumed to be at `/passbook/:token` and `/ack/:token` (§21.2). If they differ, edit `lib/public-links.ts` only.
2. **No route clashes.** No existing `/portal`, `/assistant` or `app/(public)/portal`. If a `middleware.ts`/`proxy.ts` guards routes, `/portal/*` must stay public.
3. **Path alias.** The tsconfig `@/*` alias must cover `components/`.
4. **Rate limiting.** Public calls go through the Next `/api` rewrite. Check that the API's throttler sees the citizen's IP, not the portal server's. Otherwise every citizen shares one 60/min bucket.

## Backend follow-ups (other owners — not done here)
- **WS1 + WS5 API:** `GET /public/villages` reads `villages/sub_districts/districts/states` directly, not through a `public_*` view (G22). Needs a `public_villages` view.
- **WS4/WS5:** no public download for notice documents. The UI shows the SHA-256 and "get a copy from the Collector's office".
- **Optional, WS1:** objection status lookup by a safe random reference, and a public objection-window view.
- **Spec drift, WS3/WS1:** §21.2 says a dispute "creates a grievance" and §19 says the passbook shows "grievance status". Neither is implemented, so the grievance hub routes to existing channels only.
- **i18n:** CLAUDE.md names next-intl, which isn't installed. This uses a typed dictionary. Swapping to next-intl later needs a `package.json` change (Chaitanya's OK).

## Checks run here (no repo access)
- `tsc --strict` (noUnusedLocals, noUncheckedIndexedAccess) over every new/modified file against React/Next/TanStack type stubs: 0 errors.
- Node tests for token parsing, role routing and i18n helpers. They also check every hi/mr key exists and no UI string contains a statutory literal (G8).
- Grep scan: no `dangerouslySetInnerHTML`, no `Date.now()`/`new Date()`, only existing endpoints called.
- Still to run in the repo: `pnpm lint && pnpm typecheck && pnpm test && pnpm --filter @bhoomisetu/portal build`.
